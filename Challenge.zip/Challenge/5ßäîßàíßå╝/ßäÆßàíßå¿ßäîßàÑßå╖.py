# 학점 부여기

grade = int(input("학점을 입력하세요"))

if grade == 90:
    print("A")
elif grade == 80:
    print("B")
elif grade == 80:
    print("C")
elif grade == 80:
    print("D")
else:
    print("F")
