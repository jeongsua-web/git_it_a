a = int(input("첫 번째 숫자를 입력: "))
b = int(input("두 번째 숫자를 입력: "))
c = int(input("세 번째 숫자를 입력: "))
sum = a+b+c
avg = sum/3
print(f"숫자 {a}와 {b}와 {c}의 합은 {sum}이고, 평균은 {avg}입니다.")
