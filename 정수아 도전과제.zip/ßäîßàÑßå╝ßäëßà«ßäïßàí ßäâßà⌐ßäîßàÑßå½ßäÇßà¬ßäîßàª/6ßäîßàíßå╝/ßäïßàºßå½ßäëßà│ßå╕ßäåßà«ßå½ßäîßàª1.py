# 2~100 사이의 짝수 출력

for i in range(1,101):
    if (i % 2 == 0):
        print(i, end = " ")
